package upkeepxpteam.upkeepxp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class TelaInicialActivity extends AppCompatActivity {

    //DrawerActivity drawerActivity = new DrawerActivity();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_inicial);

        //drawerActivity.setVisible(true);
    }
}
